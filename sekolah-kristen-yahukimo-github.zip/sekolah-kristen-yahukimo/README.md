# Website Sekolah Kristen Yahukimo (SMP & SMA)

Template website profil statis untuk diterbitkan menggunakan GitHub Pages.

## Berkas
- `index.html` — halaman lengkap beserta desain responsif, CSS, dan JavaScript.
- `assets/` — tempat menaruh foto asli sekolah yang sudah mendapat izin publikasi.

## Cara menerbitkan dengan GitHub Pages
1. Masuk ke https://github.com dan buat repository baru bernama `sekolah-kristen-yahukimo`.
2. Pilih **Public** jika menggunakan GitHub Free, lalu buat repository.
3. Pilih **Add file → Upload files**, unggah `index.html`, `README.md`, dan folder `assets` bila sudah memiliki foto.
4. Klik **Commit changes**.
5. Buka **Settings → Pages** pada repository.
6. Di bagian **Build and deployment**, pilih **Deploy from a branch**.
7. Pada **Branch**, pilih `main` dan folder `/ (root)`, lalu klik **Save**.
8. Tunggu proses publikasi selesai. URL biasanya berbentuk `https://USERNAME.github.io/sekolah-kristen-yahukimo/`, dengan `USERNAME` diganti nama akun GitHub.

## Sebelum diumumkan
- Ganti penanda `[Masukkan ...]` dengan informasi resmi.
- Tambahkan sejarah, visi-misi, nama pimpinan, alamat, nomor telepon, dan email hanya setelah terverifikasi.
- Ganti kotak galeri dengan foto asli sekolah yang boleh dipublikasikan.
- Untuk mengaktifkan formulir email, isi variabel `email` pada skrip di bagian bawah `index.html` dengan email resmi sekolah.

GitHub Pages cocok untuk website statis HTML/CSS/JavaScript. Untuk fitur dinamis seperti login, database siswa, atau pengelolaan berita melalui dashboard, dibutuhkan layanan/backend tambahan.
